package stepDefinitions;
import utilities.*;

import java.io.IOException;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects_makeMyTrip.*;

public class fetchSuvprice extends baseClass {

	@Given("Cab List page for given search conditions is displayed")
	public void cab_list_page_for_given_search_conditions_is_displayed() {
		System.out.println("The list of cars for hire is displayed");
	    
	}

	@When("Select SUV and display prices")
	public void select_suv_and_display_prices() {
		LowerPriceSuv c= new LowerPriceSuv();
		  c.SUV_CheckBox();
	}

	@Then("Lowest price is fetched")
	public void lowest_price_is_fetched() throws IOException, InterruptedException {
		LowerPriceSuv c= new LowerPriceSuv();
		 c.getLowerPrice();
	}




}
