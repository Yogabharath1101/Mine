package pageObjects_makeMyTrip;

import java.io.IOException;
import java.util.Iterator;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Testng_testcases.baseTest;
import utilities.baseClass;
import utilities.excel_Data;

public class Gift_card extends baseClass {
	
	@FindBy(xpath="//span[@class='chNavText' and contains(.,'More')]")
	WebElement more;
	
	@FindBy(xpath="//a[@class='appendBottom5 blackText' and contains(.,'Giftcards')]")
	WebElement giftLink;
	
	@FindBy(xpath="//div[@class='card__data' and contains(.,'Diwali')]")
	WebElement diwaliGiftCard;
	
	@FindBy(xpath="//p[text()='Sender Details']")
	WebElement details;
	
	@FindBy(xpath="//input[@name='senderName']")
	WebElement name;
	
	@FindBy(xpath="//input[@name='senderMobileNo']")
	WebElement mobileNumber;
	
	@FindBy(xpath="//input[@name='senderEmailId']")
	WebElement emailId;
	
	@FindBy(xpath="//button[@class='prime__btn font16 prime__btn__text']")
	WebElement buyNow;
	
	@FindBy(xpath="//p[contains(.,'Please enter a valid Email id')]")
	WebElement mailErrormessage;

	public Gift_card() {
		// TODO Auto-generated constructor stub
		PageFactory.initElements(driver, this);
	}
	
	public void hover()
	{
		Actions act = new Actions(driver);
    	act.moveToElement(more).moveToElement(giftLink).click().build().perform();
	}
	
	public void cardSelect()
	{
		diwaliGiftCard.click();
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
    	js.executeScript("arguments[0].scrollIntoView();",details);
    	try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
	}
	
	public void enterValues(String[] arr) throws InterruptedException, IOException
	{
		name.click();
    	name.sendKeys(arr[0]);
    	mobileNumber.click();
    	Thread.sleep(2000);
    	mobileNumber.sendKeys(arr[1].toString());
    	emailId.click();
    	emailId.sendKeys(arr[2]);
    	buyNow.click();
    	String msg=mailErrormessage.getText();
    
         //excel_Data data= new excel_Data();
    	excel_Data.setCellData(2, 0, msg);
    	 log.info("Gift card data is being entered and error message is fetched");
    	System.out.println(msg);
		
	}
}
