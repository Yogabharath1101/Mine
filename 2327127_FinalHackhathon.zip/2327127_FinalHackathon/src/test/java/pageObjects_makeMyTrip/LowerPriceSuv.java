package pageObjects_makeMyTrip;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Testng_testcases.baseTest;
import utilities.baseClass;
import utilities.excel_Data;

public class LowerPriceSuv extends baseClass {
	
	@FindBy(xpath="//label[contains(.,'SUV')]")
	WebElement suvcheckbox;
	
	@FindBy(xpath="//span[@class='latoBlack font20 appendRight5']")
	List<WebElement> carName;
	
	@FindBy(xpath="//p[@class='font28 latoBlack blackText ']")
	List<WebElement> carPrice;

	public LowerPriceSuv() {
		// TODO Auto-generated constructor stub
		PageFactory.initElements(driver, this);
	}
	

	
	public void SUV_CheckBox()
	{
		suvcheckbox.click();
		log.info("Selecting the suv cars");
	}
	
	public void getLowerPrice() throws IOException, InterruptedException
	{
		
		 System.out.println("Car Names"+"  "+"Prices");
	        System.out.println("----------"+"  "+"--------");
	        	 Iterator<WebElement> iterator1 = carName.iterator();
	             Iterator<WebElement> iterator2 = carPrice.iterator();
	            excel_Data d= new excel_Data();
	             while (iterator1.hasNext() && iterator2.hasNext()) {
	                 WebElement element1 = iterator1.next();
	                 WebElement element2 = iterator2.next();

	                 System.out.println(element1.getText() + "  " + element2.getText());
	                 
	             }
	             System.out.println("Lowest Price in the above list");
	             excel_Data.setCellData(1, 0, carName.get(0).getText());
	             Thread.sleep(2000);
	             excel_Data dd = new excel_Data();
	            dd.setCellData(1, 1, carPrice.get(0).getText());
	             
	             System.out.println(carName.get(0).getText()+"\t"+carPrice.get(0).getText());
	             log.info("Displaying all available cabs with name and price");
	             

	                  
		
	}

}
