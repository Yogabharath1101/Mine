package pageObjects_makeMyTrip;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Testng_testcases.baseTest;
import utilities.baseClass;
import utilities.excel_Data;

public class Hotel_book extends baseClass {
	

   
	@FindBy(xpath="//div[@class='chHeaderContainer']")
	WebElement mainheader;
	
	@FindBy(xpath="//a[@class='headerIcons makeFlex hrtlCenter column' and contains(.,'Hotels')]")
	WebElement hotelTab;
	
	@FindBy(xpath="//input[@id='guest']")
	WebElement guestDropDown;
	
	@FindBy(xpath="//span[@class='gstSlct__text' and @data-testid = 'adult_count']")
	WebElement adultDropDown;
	
	@FindBy(xpath="//li[@data-cy='GuestSelect$$_323']")
	List<WebElement> adultList;
	
	
	public Hotel_book() {
		// TODO Auto-generated constructor stub
		PageFactory.initElements(driver, this);
	}
	

	
	public void hotel_search() throws InterruptedException
	{   Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor)driver;
    	js.executeScript("arguments[0].scrollIntoView();", mainheader);
    	Thread.sleep(2000);
    	 log.info("Hotels tab is clicked and further process will undergo");
    	hotelTab.click();
    	guestDropDown.click();
    	adultDropDown.click();
	}
	
	public void Adult_list() throws IOException
	{   int i=3;
		System.out.println("The list of number of adults allowed:");
    	for(WebElement adultSelectabledata :adultList) {
    		
	            excel_Data d= new excel_Data();
	            d.setCellData(i, 0, adultSelectabledata.getText());
    		System.out.println(adultSelectabledata.getText());
    		i++;
    		}
    	 log.info("Selectable data under number of adults is fetched");
	}
	

}
