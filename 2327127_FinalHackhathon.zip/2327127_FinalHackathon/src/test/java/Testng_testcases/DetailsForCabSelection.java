package Testng_testcases;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.Test;

import pageObjects_makeMyTrip.*;
import utilities.Property_reader;
import utilities.baseClass;
public class DetailsForCabSelection extends baseClass {
	
	
@Test(priority=0)
public void clickCabs() throws InterruptedException, IOException {	
	 Home_Page s = new Home_Page();
	  s.clickOnCabIcon();
}
	
	
  @Test(priority=1,dependsOnMethods="clickCabs")
  public void placeSelect() throws InterruptedException, IOException {
	  
	  
	  Home_Page s = new Home_Page();
	  
	  String[] datas={"Boarding","Destination"};
	  Property_reader read=new Property_reader();
	  String[] prop=read.property_read(datas);
	  
	  s.fromLocation(prop[0]);
	  s.toLocation(prop[1]);
  }
  
  @Test(priority=2,dependsOnMethods="placeSelect")
  public void dataselect() throws InterruptedException {
	  Home_Page s = new Home_Page();
	  s.SelectDate();
	  s.SelectTime();
  }
   
}
