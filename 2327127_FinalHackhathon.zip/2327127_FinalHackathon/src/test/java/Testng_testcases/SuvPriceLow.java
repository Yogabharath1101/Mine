package Testng_testcases;

import java.io.IOException;

import org.testng.annotations.Test;

import pageObjects_makeMyTrip.*;
import utilities.baseClass;

public class SuvPriceLow extends baseClass {
  @Test(priority=1)
  public void selectSuv() {
	  LowerPriceSuv checkbox= new LowerPriceSuv();
	  checkbox.SUV_CheckBox();
	  
  }
  @Test(priority=2,dependsOnMethods= {"selectSuv"})
  public void SuvPricesLow() throws IOException, InterruptedException {
	  LowerPriceSuv lowprice= new LowerPriceSuv();
	  lowprice.getLowerPrice();
	
  }
  
  
  
}
